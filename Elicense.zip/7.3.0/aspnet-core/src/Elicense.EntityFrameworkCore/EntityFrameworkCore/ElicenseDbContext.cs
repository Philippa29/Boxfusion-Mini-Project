﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using Elicense.Authorization.Roles;
using Elicense.Authorization.Users;
using Elicense.MultiTenancy;

namespace Elicense.EntityFrameworkCore
{
    public class ElicenseDbContext : AbpZeroDbContext<Tenant, Role, User, ElicenseDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public ElicenseDbContext(DbContextOptions<ElicenseDbContext> options)
            : base(options)
        {
        }
    }
}
