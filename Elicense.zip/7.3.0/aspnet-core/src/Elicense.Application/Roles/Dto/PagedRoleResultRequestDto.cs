﻿using Abp.Application.Services.Dto;

namespace Elicense.Roles.Dto
{
    public class PagedRoleResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}

