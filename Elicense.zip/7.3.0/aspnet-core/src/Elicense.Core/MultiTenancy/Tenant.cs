﻿using Abp.MultiTenancy;
using Elicense.Authorization.Users;

namespace Elicense.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
